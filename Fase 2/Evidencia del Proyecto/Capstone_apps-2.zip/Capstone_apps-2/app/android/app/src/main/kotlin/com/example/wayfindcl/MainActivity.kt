package com.example.wayfindcl

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
